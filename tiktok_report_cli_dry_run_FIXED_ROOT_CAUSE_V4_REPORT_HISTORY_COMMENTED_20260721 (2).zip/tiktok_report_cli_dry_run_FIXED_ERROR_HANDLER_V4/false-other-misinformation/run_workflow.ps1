﻿param(
    [string]$Config = "$PSScriptRoot\config.json"
)

$ErrorActionPreference = "Stop"
$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = $Utf8NoBom
$OutputEncoding = $Utf8NoBom
Set-Location $PSScriptRoot

if (-not (Get-Command adb -ErrorAction SilentlyContinue)) {
    throw "adb.exe tidak ditemukan di PATH."
}

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    throw "Python tidak ditemukan di PATH."
}

try {
    python -c "import uiautomator2"
}
catch {
    python -m pip install -U uiautomator2
}

python "$PSScriptRoot\tiktok_live_selector_workflow.py" `
    --config $Config

exit $LASTEXITCODE
