@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
cd /d "%~dp0"

echo ============================================================
echo TikTok LIVE Selector-Only Workflow
echo.
echo - ADB TCP configurable
echo - LIVE URL configurable
echo - No fixed coordinates
echo - No coordinate ratios
echo - No swipe
echo - TikTok always closes at the end
echo ============================================================
echo.

where adb >nul 2>nul
if errorlevel 1 (
    echo ERROR: adb.exe tidak ditemukan di PATH.
    pause
    exit /b 1
)

where python >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python tidak ditemukan di PATH.
    pause
    exit /b 1
)

python -c "import uiautomator2" >nul 2>nul
if errorlevel 1 (
    echo Installing uiautomator2...
    python -m pip install -U uiautomator2
    if errorlevel 1 (
        echo ERROR: instalasi uiautomator2 gagal.
        pause
        exit /b 1
    )
)

python "%~dp0tiktok_live_selector_workflow.py" ^
    --config "%~dp0config.json"

set CODE=%ERRORLEVEL%

echo.
echo Exit code: %CODE%
echo Logs: %~dp0logs
echo.
pause
exit /b %CODE%
