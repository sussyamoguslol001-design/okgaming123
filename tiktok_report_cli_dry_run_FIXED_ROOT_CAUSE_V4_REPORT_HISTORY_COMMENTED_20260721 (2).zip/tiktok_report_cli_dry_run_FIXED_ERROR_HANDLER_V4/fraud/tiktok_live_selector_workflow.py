#!/usr/bin/env python3
"""
TikTok LIVE selector-only workflow over ADB TCP.

Recorded-session mapping:
1. Open broadcaster profile:
   resource ID com.ss.android.ugc.trill:id/b09
2. Open Report:
   resource ID com.ss.android.ugc.trill:id/a2v
   content description Report
3. Choose reason:
   exact visible text, default "Frauds and scams"
4. Submit:
   exact visible text "Submit"
5. Finish:
   exact visible text "Done"
6. Always force-close TikTok.

No fixed coordinates or screen ratios are used.
Reason scrolling uses Android scrollable UI elements only.
Every action is resolved from the current Android UI hierarchy.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import re
import shutil
import subprocess
import sys
import time
import traceback
import unicodedata
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterable, Optional, Sequence


def configure_utf8_streams() -> None:
    """Allow console logging of TikTok names containing emoji/Unicode."""
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is None or not hasattr(stream, "reconfigure"):
            continue
        try:
            stream.reconfigure(encoding="utf-8", errors="backslashreplace")
        except (OSError, ValueError):
            pass


configure_utf8_streams()

try:
    import uiautomator2 as u2
except ImportError:
    print("ERROR: uiautomator2 belum terpasang.")
    print("Jalankan: python -m pip install -U uiautomator2")
    raise SystemExit(2)


TIKTOK_PACKAGES = (
    "com.ss.android.ugc.trill",
    "com.zhiliaoapp.musically",
    "com.ss.android.ugc.aweme",
)


class WorkflowError(RuntimeError):
    pass


class LiveUnavailableError(WorkflowError):
    """Raised when the requested TikTok LIVE is no longer active."""


BUILD_ID = "2026.07.21-DRY-ROOT-CAUSE-V4"


@dataclass
class SelectorSpec:
    name: str
    method: str
    values: dict[str, str]


@dataclass
class LocatedElement:
    action: str
    selector: SelectorSpec
    selector_count: int
    resource_id: str
    text: str
    description: str
    class_name: str
    bounds: tuple[int, int, int, int]
    clickable: bool
    enabled: bool


def normalize(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip())


def normalize_identity(value: Any) -> str:
    """Normalize a username/display name for report-history comparison."""
    text = unicodedata.normalize("NFKC", str(value or ""))
    text = text.casefold().replace("@", "")
    text = re.sub(r"\s+", " ", text).strip()
    return text


def safe_name(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", normalize(value))
    return value[:90] or "unknown"


def parse_live_url(url: str) -> str:
    match = re.fullmatch(
        r"https?://(?:www\.)?tiktok\.com/@([A-Za-z0-9._]+)/live/?",
        normalize(url),
        flags=re.IGNORECASE,
    )
    if not match:
        raise WorkflowError(
            "live_url harus berbentuk "
            "https://www.tiktok.com/@username/live"
        )
    return match.group(1)


def parse_bounds(raw: Any) -> Optional[tuple[int, int, int, int]]:
    if isinstance(raw, dict):
        try:
            left = int(raw["left"])
            top = int(raw["top"])
            right = int(raw["right"])
            bottom = int(raw["bottom"])
        except (KeyError, TypeError, ValueError):
            return None
        if right > left and bottom > top:
            return left, top, right, bottom
        return None

    match = re.fullmatch(
        r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]",
        normalize(raw),
    )
    if not match:
        return None

    left, top, right, bottom = map(int, match.groups())
    if right <= left or bottom <= top:
        return None
    return left, top, right, bottom


class TikTokSelectorWorkflow:
    def __init__(self, config_path: Path) -> None:
        self.config_path = config_path.resolve()
        self.base_dir = self.config_path.parent
        self.config = self.load_config(self.config_path)

        self.serial = normalize(self.config["adb_serial"])
        self.live_url = normalize(self.config["live_url"])
        self.live_username = parse_live_url(self.live_url)

        self.package: Optional[str] = None
        self.device = None
        self.current_stage = "INIT"
        self.current_action = ""
        self.last_selector_diagnostics: list[dict[str, Any]] = []
        self.installed_packages: list[str] = []
        self.optional_cleanup_actions: list[str] = []
        self.last_selector_failure_kind = ""
        self.source_sha256 = hashlib.sha256(
            Path(__file__).read_bytes()
        ).hexdigest()
        self.broadcaster_identity_candidates: list[str] = []
        self.report_history_check = "not_run_dry"
        self.report_history_name_match = False
        self.report_history_matched_value = ""
        self.last_error_evidence = ""

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_root = self.resolve_path(
            self.config.get("log_root", "logs")
        )
        self.run_dir = log_root / f"run_{timestamp}"
        self.run_dir.mkdir(parents=True, exist_ok=True)

        self.logger = self.create_logger()

    @staticmethod
    def load_config(path: Path) -> dict[str, Any]:
        if not path.exists():
            raise SystemExit(f"Config tidak ditemukan: {path}")

        try:
            config = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise SystemExit(
                f"config.json tidak valid pada baris "
                f"{exc.lineno}, kolom {exc.colno}: {exc.msg}"
            ) from exc

        for key in ("adb_serial", "live_url"):
            if not normalize(config.get(key)):
                raise SystemExit(
                    f"Nilai config wajib tidak tersedia: {key}"
                )

        return config

    def resolve_path(self, value: str) -> Path:
        path = Path(value)
        if path.is_absolute():
            return path
        return self.base_dir / path

    def create_logger(self) -> logging.Logger:
        logger = logging.getLogger(
            f"tiktok_selector_workflow_{id(self)}"
        )
        logger.handlers.clear()
        logger.setLevel(logging.INFO)

        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )

        console = logging.StreamHandler(sys.stdout)
        console.setLevel(logging.INFO)
        console.setFormatter(formatter)

        file_handler = logging.FileHandler(
            self.run_dir / "automation.log",
            encoding="utf-8",
        )
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(formatter)

        logger.addHandler(console)
        logger.addHandler(file_handler)
        logger.propagate = False
        return logger

    def run_process(
        self,
        command: Sequence[str],
        *,
        timeout: int = 30,
        check: bool = False,
        binary: bool = False,
    ):
        display_command = subprocess.list2cmdline(
            [str(part) for part in command]
        )

        try:
            result = subprocess.run(
                [str(part) for part in command],
                capture_output=True,
                text=not binary,
                encoding=None if binary else "utf-8",
                errors=None if binary else "replace",
                timeout=timeout,
                check=False,
            )
        except FileNotFoundError as exc:
            raise WorkflowError(
                f"Executable tidak ditemukan: {command[0]}"
            ) from exc
        except subprocess.TimeoutExpired as exc:
            raise WorkflowError(
                f"Command timeout setelah {timeout} detik: "
                f"{display_command}"
            ) from exc

        if check and result.returncode != 0:
            raise WorkflowError(
                f"Command gagal: {display_command}\n"
                f"{result.stderr or result.stdout}"
            )

        return result

    def adb(
        self,
        *args: str,
        timeout: int = 30,
        check: bool = False,
        include_serial: bool = True,
        binary: bool = False,
    ):
        command = ["adb"]
        if include_serial:
            command.extend(["-s", self.serial])
        command.extend(args)
        return self.run_process(
            command,
            timeout=timeout,
            check=check,
            binary=binary,
        )

    def set_stage(self, code: str, label: str) -> None:
        self.current_stage = code
        self.current_action = label
        self.logger.info("STEP | %s | %s", code, label)

    def safe_adb_text(
        self,
        *args: str,
        timeout: int = 12,
        default: str = "unknown",
    ) -> str:
        try:
            result = self.adb(*args, timeout=timeout)
            value = normalize(result.stdout)
            return value or default
        except Exception as exc:
            self.logger.warning(
                "ADB metadata unavailable | command=%s | error=%s",
                " ".join(args),
                exc,
            )
            return default

    def safe_getprop(self, name: str) -> str:
        return self.safe_adb_text(
            "shell", "getprop", name, timeout=12
        )

    def connect(self) -> None:
        if shutil.which("adb") is None:
            raise WorkflowError("adb.exe tidak tersedia di PATH.")

        self.run_process(["adb", "version"], timeout=15, check=True)
        self.logger.info("ADB target: %s", self.serial)

        state = ""
        try:
            state_result = self.adb("get-state", timeout=10)
            if state_result.returncode == 0:
                state = normalize(state_result.stdout)
        except Exception as exc:
            self.logger.warning("ADB state check awal gagal: %s", exc)

        if state == "device":
            self.logger.info("ADB TCP sudah terhubung; adb connect dilewati.")
        else:
            connected = False
            last_error = ""
            for attempt in range(1, 4):
                self.logger.info(
                    "ADB connect attempt %d/3: %s", attempt, self.serial
                )
                try:
                    result = self.adb(
                        "connect",
                        self.serial,
                        include_serial=False,
                        timeout=25,
                    )
                    combined = normalize(
                        f"{result.stdout} {result.stderr}"
                    ).lower()
                    bad = any(
                        marker in combined
                        for marker in (
                            "failed", "unable", "refused", "cannot", "no route"
                        )
                    )
                    if result.returncode == 0 and not bad:
                        self.adb("wait-for-device", timeout=35, check=True)
                        state_result = self.adb(
                            "get-state", timeout=15, check=True
                        )
                        if normalize(state_result.stdout) == "device":
                            connected = True
                            break
                    last_error = combined or f"exit={result.returncode}"
                except Exception as exc:
                    last_error = str(exc)
                if attempt < 3:
                    time.sleep(float(attempt))

            if not connected:
                raise WorkflowError(
                    f"Gagal menghubungkan ADB TCP {self.serial} setelah 3 "
                    f"percobaan. Detail terakhir: {last_error}"
                )

        last_u2_error = ""
        for attempt in range(1, 4):
            try:
                self.device = u2.connect(self.serial)
                # A lightweight RPC confirms the uiautomator2 service is alive.
                self.device.window_size()
                break
            except Exception as exc:
                last_u2_error = str(exc)
                self.logger.warning(
                    "uiautomator2 connect attempt %d/3 gagal: %s",
                    attempt,
                    exc,
                )
                if attempt < 3:
                    time.sleep(float(attempt))
        else:
            raise WorkflowError(
                "uiautomator2 tidak dapat terhubung setelah 3 percobaan: "
                + last_u2_error
            )

        try:
            self.device.jsonrpc.setConfigurator(
                {"waitForIdleTimeout": 0, "waitForSelectorTimeout": 0}
            )
        except Exception as exc:
            self.logger.warning("Tidak dapat menonaktifkan idle wait: %s", exc)

        width, height = self.device.window_size()
        metadata = {
            "connected_at": datetime.now().isoformat(timespec="milliseconds"),
            "adb_serial": self.serial,
            "manufacturer": self.safe_getprop("ro.product.manufacturer"),
            "model": self.safe_getprop("ro.product.model"),
            "device": self.safe_getprop("ro.product.device"),
            "android_version": self.safe_getprop("ro.build.version.release"),
            "sdk": self.safe_getprop("ro.build.version.sdk"),
            "window_width": width,
            "window_height": height,
            "wm_size": self.safe_adb_text("shell", "wm", "size"),
            "wm_density": self.safe_adb_text("shell", "wm", "density"),
            "fixed_coordinates_used": False,
            "coordinate_ratios_used": False,
            "source_sha256": self.source_sha256,
            "dry_run_submit_done": "commented",
            "report_history_check": self.report_history_check,
            "report_history_name_match": self.report_history_name_match,
            "report_history_matched_value": self.report_history_matched_value,
        }
        (self.run_dir / "device_metadata.json").write_text(
            json.dumps(metadata, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        self.logger.info(
            "Device: %s %s, window=%dx%d",
            metadata["manufacturer"],
            metadata["model"],
            width,
            height,
        )

    def getprop(self, name: str) -> str:
        return self.adb(
            "shell",
            "getprop",
            name,
            timeout=12,
        ).stdout.strip()

    def detect_package(self) -> str:
        configured = normalize(self.config.get("tiktok_package", "auto"))
        result = self.adb(
            "shell", "pm", "list", "packages", timeout=35, check=True
        )
        installed = sorted(
            {
                line.split(":", 1)[1].strip()
                for line in result.stdout.splitlines()
                if line.startswith("package:")
            }
        )
        self.installed_packages = installed

        if configured and configured != "auto":
            if configured not in installed:
                raise WorkflowError(
                    f"Package TikTok tidak terpasang: {configured}"
                )
            self.package = configured
        else:
            self.package = next(
                (candidate for candidate in TIKTOK_PACKAGES if candidate in installed),
                None,
            )

            if not self.package:
                markers = (
                    "tiktok", "musically", "ugc.trill", "ugc.aweme"
                )
                heuristic = [
                    package
                    for package in installed
                    if any(marker in package.lower() for marker in markers)
                ]
                if len(heuristic) == 1:
                    self.package = heuristic[0]
                    self.logger.warning(
                        "TikTok package detected heuristically: %s",
                        self.package,
                    )

        if not self.package:
            related = [
                package
                for package in installed
                if any(
                    marker in package.lower()
                    for marker in ("tiktok", "musically", "aweme", "trill")
                )
            ]
            related_text = ", ".join(related[:20]) or "none"
            raise WorkflowError(
                "Package TikTok tidak ditemukan. TikTok mungkin belum "
                "terpasang atau menggunakan package name baru. "
                f"Paket terkait yang ditemukan: {related_text}"
            )

        self.logger.info("Package TikTok: %s", self.package)
        return self.package

    def current_app(self) -> dict[str, str]:
        assert self.device is not None
        try:
            current = self.device.app_current()
            return {
                "package": normalize(current.get("package")),
                "activity": normalize(current.get("activity")),
            }
        except Exception:
            return {
                "package": "",
                "activity": "",
            }

    def save_state(self, prefix: str) -> None:
        # Keep successful runs compact. Create one concise text diagnostic
        # only when a precondition, selector, or postcondition fails.
        if not prefix.startswith("error_"):
            return

        assert self.device is not None

        lines = [
            f"timestamp={datetime.now().isoformat(timespec='milliseconds')}",
            f"build={BUILD_ID}",
            f"adb_serial={self.serial}",
            f"live_url={self.live_url}",
            f"current_app={json.dumps(self.current_app(), ensure_ascii=False)}",
            "",
            "VISIBLE UI NODES",
            "resource_id | class | text | description | bounds | clickable | enabled",
        ]

        try:
            hierarchy = self.device.dump_hierarchy(compressed=False)
            root = ET.fromstring(hierarchy)

            node_count = 0
            for node in root.iter("node"):
                resource_id = normalize(node.attrib.get("resource-id"))
                class_name = normalize(node.attrib.get("class"))
                text = normalize(node.attrib.get("text"))
                description = normalize(
                    node.attrib.get("content-desc")
                )
                bounds = normalize(node.attrib.get("bounds"))
                clickable = normalize(node.attrib.get("clickable"))
                enabled = normalize(node.attrib.get("enabled"))

                if not (resource_id or text or description):
                    continue

                lines.append(
                    f"{resource_id} | {class_name} | {text!r} | "
                    f"{description!r} | {bounds} | "
                    f"{clickable} | {enabled}"
                )
                node_count += 1

                if node_count >= 300:
                    lines.append("... diagnostic truncated at 300 nodes ...")
                    break

        except Exception as exc:
            lines.append(f"UI hierarchy unavailable: {exc}")

        diagnostic_path = (
            self.run_dir / f"{safe_name(prefix)}_ui.txt"
        )
        diagnostic_path.write_text(
            "\n".join(lines) + "\n",
            encoding="utf-8",
        )
        self.logger.info(
            "Diagnostik UI teks disimpan: %s",
            diagnostic_path,
        )

    def live_unavailable_reason(self) -> str:
        """Read the current UI once and identify a finished LIVE screen."""
        assert self.device is not None

        try:
            hierarchy = self.device.dump_hierarchy(
                compressed=True,
            ).lower()
        except Exception:
            return ""

        markers = (
            ("live has ended", "LIVE has ended"),
            ("this live has ended", "LIVE has ended"),
            ("live is unavailable", "LIVE is unavailable"),
            ("live unavailable", "LIVE is unavailable"),
            ("siaran live telah berakhir", "Siaran LIVE telah berakhir"),
            ("live telah berakhir", "Siaran LIVE telah berakhir"),
            ("siaran langsung telah berakhir", "Siaran LIVE telah berakhir"),
        )

        for marker, label in markers:
            if marker in hierarchy:
                return label

        return ""

    def open_live(self) -> None:
        assert self.package

        self.logger.info(
            "Membuka TikTok LIVE: %s",
            self.live_url,
        )

        result = self.adb(
            "shell",
            "am",
            "start",
            "-W",
            "-a",
            "android.intent.action.VIEW",
            "-d",
            self.live_url,
            "-p",
            self.package,
            timeout=45,
        )

        combined = (
            f"{result.stdout}\n{result.stderr}"
        ).lower()

        if result.returncode != 0 or any(
            marker in combined
            for marker in (
                "error:",
                "unable to resolve intent",
                "exception",
            )
        ):
            raise WorkflowError(
                f"Gagal membuka URL LIVE:\n"
                f"{result.stdout}{result.stderr}"
            )

        self.wait_for_live_ready()

    def wait_for_live_ready(self) -> None:
        assert self.device is not None
        assert self.package

        timeout = float(
            self.config.get(
                "live_ready_timeout_seconds",
                20,
            )
        )
        interval = float(
            self.config.get(
                "poll_interval_seconds",
                0.4,
            )
        )
        started_at = time.monotonic()
        deadline = started_at + timeout
        relaunch_at = started_at + min(6.0, timeout / 2.0)
        relaunch_attempted = False

        last = {}

        while time.monotonic() < deadline:
            last = self.current_app()

            if last["package"] != self.package:
                time.sleep(interval)
                continue

            activity_ok = any(
                normalize(fragment).lower()
                in last["activity"].lower()
                for fragment in self.config.get(
                    "live_activity_contains",
                    [
                        "LivePlayActivity",
                        ".live.",
                    ],
                )
            )

            # LivePlayActivity is the authoritative LIVE-readiness signal.
            # The host-profile selector is checked by the next unchanged step.
            if activity_ok:
                self.logger.info(
                    "LIVE siap: activity=%s",
                    last["activity"],
                )
                self.save_state("01_live_ready")
                return

            if (
                not relaunch_attempted
                and time.monotonic() >= relaunch_at
                and last.get("package") == self.package
                and "mainactivity" in last.get("activity", "").lower()
            ):
                relaunch_attempted = True
                self.logger.warning(
                    "Deep link masih berada di MainActivity; "
                    "mencoba URL LIVE satu kali lagi."
                )
                try:
                    self.adb(
                        "shell",
                        "am",
                        "start",
                        "-W",
                        "-a",
                        "android.intent.action.VIEW",
                        "-d",
                        self.live_url,
                        "-p",
                        self.package,
                        timeout=45,
                    )
                except Exception as exc:
                    self.logger.warning(
                        "Percobaan ulang deep link gagal: %s",
                        exc,
                    )

            time.sleep(interval)

        unavailable = self.live_unavailable_reason()
        if unavailable:
            raise LiveUnavailableError(
                f"{unavailable}: {self.live_url}"
            )

        if (
            last.get("package") == self.package
            and "mainactivity" in last.get("activity", "").lower()
        ):
            raise LiveUnavailableError(
                "URL LIVE tetap berada di MainActivity setelah satu "
                "percobaan ulang. LIVE kemungkinan sudah berakhir "
                "atau tidak tersedia: "
                f"{self.live_url}"
            )

        self.save_state("error_live_not_ready")
        raise WorkflowError(
            "TikTok LIVE tidak siap sebelum timeout. "
            f"Current app: {last}"
        )

    def selector_specs(
        self,
        selector_config: dict[str, Any],
    ) -> list[SelectorSpec]:
        specs = []

        resource_id = normalize(
            selector_config.get("resource_id")
        )
        description = normalize(
            selector_config.get("description")
        )
        text = normalize(
            selector_config.get("text")
        )
        class_name = normalize(
            selector_config.get("class_name")
        )

        if resource_id and description:
            specs.append(
                SelectorSpec(
                    name="resource_id+description",
                    method="ui-selector",
                    values={
                        "resourceId": resource_id,
                        "description": description,
                    },
                )
            )

        if resource_id and text:
            specs.append(
                SelectorSpec(
                    name="resource_id+text",
                    method="ui-selector",
                    values={
                        "resourceId": resource_id,
                        "text": text,
                    },
                )
            )

        if resource_id and class_name:
            specs.append(
                SelectorSpec(
                    name="resource_id+class",
                    method="ui-selector",
                    values={
                        "resourceId": resource_id,
                        "className": class_name,
                    },
                )
            )

        if resource_id:
            specs.append(
                SelectorSpec(
                    name="resource_id",
                    method="ui-selector",
                    values={
                        "resourceId": resource_id,
                    },
                )
            )

        for alternate_resource_id in selector_config.get(
            "alternate_resource_ids",
            [],
        ):
            alternate_resource_id = normalize(alternate_resource_id)
            if not alternate_resource_id:
                continue
            if class_name:
                specs.append(
                    SelectorSpec(
                        name="alternate-resource-id+class",
                        method="ui-selector",
                        values={
                            "resourceId": alternate_resource_id,
                            "className": class_name,
                        },
                    )
                )
            specs.append(
                SelectorSpec(
                    name="alternate-resource-id",
                    method="ui-selector",
                    values={"resourceId": alternate_resource_id},
                )
            )

        if selector_config.get(
            "use_live_username_as_description_contains",
            False,
        ):
            username_variants = []
            for username_variant in (
                self.live_username,
                self.live_username.upper(),
            ):
                if username_variant and username_variant not in username_variants:
                    username_variants.append(username_variant)
            for username_variant in username_variants:
                values = {"descriptionContains": username_variant}
                if class_name:
                    values["className"] = class_name
                specs.append(
                    SelectorSpec(
                        name="live-username-description-contains",
                        method="ui-selector",
                        values=values,
                    )
                )

        if selector_config.get(
            "use_live_username_as_text_contains",
            False,
        ):
            # Disabled by default in config. A broad textContains selector can
            # match comments or profile text instead of the host button.
            values = {"textContains": self.live_username}
            if class_name:
                values["className"] = class_name
            specs.append(
                SelectorSpec(
                    name="live-username-text-contains",
                    method="ui-selector",
                    values=values,
                )
            )

        if description:
            specs.append(
                SelectorSpec(
                    name="description",
                    method="ui-selector",
                    values={
                        "description": description,
                    },
                )
            )

        if text:
            specs.append(
                SelectorSpec(
                    name="text",
                    method="ui-selector",
                    values={
                        "text": text,
                    },
                )
            )

        for alternate in selector_config.get(
            "alternate_texts",
            [],
        ):
            alternate = normalize(alternate)
            if alternate:
                specs.append(
                    SelectorSpec(
                        name="alternate-text",
                        method="ui-selector",
                        values={"text": alternate},
                    )
                )

        return specs

    def scroll_reason_list_once(self) -> bool:
        assert self.device is not None

        try:
            scrollables = self.device(scrollable=True)
            count = int(scrollables.count)
        except Exception:
            return False

        for index in range(count):
            try:
                container = scrollables[index]
                if bool(
                    container.scroll.vertical.forward(
                        steps=35
                    )
                ):
                    return True
            except Exception:
                continue

        return False

    def locate_unique(
        self,
        *,
        action: str,
        selector_config: dict[str, Any],
        timeout: float,
        scroll_on_miss: bool = False,
        max_scroll_attempts: int = 0,
    ) -> tuple[Any, LocatedElement]:
        assert self.device is not None
        self.current_action = action

        deadline = time.monotonic() + timeout
        poll_interval = float(
            self.config.get(
                "poll_interval_seconds",
                0.4,
            )
        )
        specs = self.selector_specs(selector_config)

        if not specs:
            raise WorkflowError(
                f"{action}: konfigurasi selector kosong."
            )

        last_diagnostics = []
        scroll_attempts = 0

        while time.monotonic() < deadline:
            last_diagnostics = []

            for spec in specs:
                try:
                    target = self.device(**spec.values)
                    count = int(target.count)

                    last_diagnostics.append(
                        {
                            "selector": spec.name,
                            "values": spec.values,
                            "count": count,
                        }
                    )

                    if count != 1:
                        continue

                    info = target.info
                    bounds = parse_bounds(
                        info.get("visibleBounds")
                        or info.get("bounds")
                    )

                    if bounds is None:
                        continue

                    if info.get("enabled") is False:
                        continue

                    located = LocatedElement(
                        action=action,
                        selector=spec,
                        selector_count=count,
                        resource_id=normalize(
                            info.get("resourceName")
                        ),
                        text=normalize(
                            info.get("text")
                        ),
                        description=normalize(
                            info.get(
                                "contentDescription"
                            )
                        ),
                        class_name=normalize(
                            info.get("className")
                        ),
                        bounds=bounds,
                        clickable=bool(
                            info.get("clickable", False)
                        ),
                        enabled=bool(
                            info.get("enabled", True)
                        ),
                    )

                    self.last_selector_diagnostics = list(last_diagnostics)
                    self.last_selector_diagnostics.append(
                        {
                            "selected": spec.name,
                            "resource_id": located.resource_id,
                            "text": located.text,
                            "description": located.description,
                            "class_name": located.class_name,
                            "bounds": located.bounds,
                            "clickable": located.clickable,
                        }
                    )
                    return target, located

                except Exception as exc:
                    last_diagnostics.append(
                        {
                            "selector": spec.name,
                            "values": spec.values,
                            "error": str(exc),
                        }
                    )

            for container_resource_id in selector_config.get(
                "clickable_child_of_resource_ids",
                [],
            ):
                container_resource_id = normalize(container_resource_id)
                if not container_resource_id:
                    continue
                try:
                    container = self.device(
                        resourceId=container_resource_id
                    )
                    container_count = int(container.count)
                    last_diagnostics.append(
                        {
                            "selector": "clickable-child-container",
                            "values": {"resourceId": container_resource_id},
                            "container_count": container_count,
                        }
                    )
                    if container_count != 1:
                        continue
                    child_values = {}
                    configured_class = normalize(
                        selector_config.get("class_name")
                    )
                    if configured_class:
                        child_values["className"] = configured_class
                    child_values["clickable"] = True
                    child_values["enabled"] = True
                    target = container.child(**child_values)
                    count = int(target.count)
                    last_diagnostics[-1]["child_count"] = count
                    if count != 1:
                        continue
                    info = target.info
                    bounds = parse_bounds(
                        info.get("visibleBounds") or info.get("bounds")
                    )
                    if bounds is None or info.get("enabled") is False:
                        continue
                    located = LocatedElement(
                        action=action,
                        selector=SelectorSpec(
                            name="clickable-child-of-container",
                            method="ui-selector-child",
                            values={
                                "containerResourceId": container_resource_id,
                                **child_values,
                            },
                        ),
                        selector_count=count,
                        resource_id=normalize(info.get("resourceName")),
                        text=normalize(info.get("text")),
                        description=normalize(
                            info.get("contentDescription")
                        ),
                        class_name=normalize(info.get("className")),
                        bounds=bounds,
                        clickable=bool(info.get("clickable", False)),
                        enabled=bool(info.get("enabled", True)),
                    )
                    if not located.clickable:
                        continue
                    self.last_selector_diagnostics = list(last_diagnostics)
                    self.last_selector_diagnostics.append(
                        {
                            "selected": located.selector.name,
                            "resource_id": located.resource_id,
                            "description": located.description,
                            "bounds": located.bounds,
                        }
                    )
                    return target, located
                except Exception as exc:
                    last_diagnostics.append(
                        {
                            "selector": "clickable-child-container",
                            "values": {"resourceId": container_resource_id},
                            "error": str(exc),
                        }
                    )

            if (
                scroll_on_miss
                and scroll_attempts < max_scroll_attempts
            ):
                self.scroll_reason_list_once()
                scroll_attempts += 1

            time.sleep(poll_interval)

        self.last_selector_diagnostics = list(last_diagnostics)

        if action == "Buka profil host LIVE":
            unavailable = self.live_unavailable_reason()
            if unavailable:
                raise LiveUnavailableError(
                    f"{unavailable}: {self.live_url}"
                )

        self.save_state(
            "error_"
            + safe_name(action)
        )

        (self.run_dir / (
            "error_"
            + safe_name(action)
            + "_selectors.json"
        )).write_text(
            json.dumps(
                last_diagnostics,
                indent=2,
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )

        observed_counts: list[int] = []
        for item in last_diagnostics:
            for key in ("count", "child_count", "container_count"):
                value = item.get(key)
                if isinstance(value, int):
                    observed_counts.append(value)

        ambiguous_counts = [value for value in observed_counts if value > 1]
        if ambiguous_counts:
            self.last_selector_failure_kind = "ambiguous"
            maximum = max(ambiguous_counts)
            raise WorkflowError(
                f"{action}: selector ambigu ({maximum} kandidat cocok); "
                "tidak aman memilih salah satu secara acak. "
                "Tidak ada koordinat fallback."
            )

        self.last_selector_failure_kind = "missing"
        raise WorkflowError(
            f"{action}: selector tidak ditemukan (0 kandidat cocok) "
            "sebelum timeout. Tidak ada koordinat fallback."
        )


    def remember_broadcaster_identity(self, located: LocatedElement) -> None:
        """Store passive identity candidates for the commented history check."""
        raw_values = [
            self.live_username,
            "@" + self.live_username,
            located.text,
            located.description,
        ]
        for raw in raw_values:
            value = normalize(raw)
            if not value:
                continue
            candidates = [value]
            # TikTok accessibility descriptions often append follower counts,
            # for example: "Display name,23.5K". Keep both forms.
            stripped = re.sub(
                r",\s*[0-9][0-9.,]*\s*[KMBkmb]?$",
                "",
                value,
            ).strip()
            if stripped and stripped != value:
                candidates.append(stripped)
            for candidate in candidates:
                normalized = normalize_identity(candidate)
                if len(normalized) < 3:
                    continue
                if normalized not in self.broadcaster_identity_candidates:
                    self.broadcaster_identity_candidates.append(normalized)
        self.logger.info(
            "BROADCASTER IDENTITY | candidates=%s",
            json.dumps(self.broadcaster_identity_candidates, ensure_ascii=False),
        )

    def click_action(
        self,
        *,
        action: str,
        selector_key: str,
        expected_before: Optional[
            Callable[[], bool]
        ] = None,
        expected_after: Optional[
            Callable[[], bool]
        ] = None,
    ) -> None:
        assert self.device is not None

        if expected_before is not None:
            if not expected_before():
                self.save_state(
                    "error_precondition_"
                    + safe_name(action)
                )
                raise WorkflowError(
                    f"{action}: precondition tidak terpenuhi."
                )

        selector_config = self.config[
            "selectors"
        ][selector_key]

        try:
            target, located = self.locate_unique(
                action=action,
                selector_config=selector_config,
                timeout=float(
                    selector_config.get(
                        "timeout_seconds",
                        self.config.get(
                            "selector_timeout_seconds",
                            12,
                        ),
                    )
                ),
                scroll_on_miss=(
                    selector_key
                    in {"report_reason", "report_subreason"}
                ),
                max_scroll_attempts=int(
                    self.config.get(
                        "reason_scroll_attempts",
                        5,
                    )
                ),
            )
        except WorkflowError as locate_exc:
            refresh_retries = int(
                self.config.get("host_profile_refresh_retry_count", 1)
            ) if selector_key == "host_profile" else 0
            if (
                refresh_retries < 1
                or "selector tidak ditemukan" not in str(locate_exc).lower()
            ):
                raise
            self.logger.warning(
                "HOST PROFILE | selector missing after initial wait; "
                "reopening the same LIVE URL once before retry."
            )
            self.open_live()
            self.optional_preflight_cleanup()
            target, located = self.locate_unique(
                action=action + " (LIVE refresh retry)",
                selector_config=selector_config,
                timeout=float(
                    self.config.get("host_profile_refresh_timeout_seconds", 8)
                ),
                scroll_on_miss=False,
                max_scroll_attempts=0,
            )

        self.logger.info(
            "SELECTOR | %s | %s | id=%s | text=%r | desc=%r | bounds=%s",
            action,
            located.selector.name,
            located.resource_id,
            located.text,
            located.description,
            located.bounds,
        )
        if selector_key == "host_profile":
            self.remember_broadcaster_identity(located)
        self.logger.info("CLICK | %s", action)

        try:
            target.click()
        except Exception as click_exc:
            click_text = str(click_exc)
            stale = (
                "-32002" in click_text
                or "UiObjectNotFound" in type(click_exc).__name__
            )
            if not stale:
                raise
            self.logger.warning(
                "CLICK selector stale; resolving the same semantic selector once. "
                "action=%s | error=%s",
                action,
                click_exc,
            )
            target, located = self.locate_unique(
                action=action + " (stale selector retry)",
                selector_config=selector_config,
                timeout=float(
                    self.config.get("stale_selector_retry_timeout_seconds", 4)
                ),
                scroll_on_miss=False,
                max_scroll_attempts=0,
            )
            self.logger.info(
                "SELECTOR RETRY | %s | %s | id=%s | text=%r | desc=%r",
                action,
                located.selector.name,
                located.resource_id,
                located.text,
                located.description,
            )
            target.click()

        wait_after = float(
            selector_config.get(
                "wait_after_seconds",
                1.5,
            )
        )

        if expected_after is None:
            time.sleep(wait_after)
            return

        poll_interval = float(
            self.config.get(
                "poll_interval_seconds",
                0.4,
            )
        )
        after_timeout = float(
            selector_config.get(
                "after_timeout_seconds",
                10,
            )
        )

        def wait_for_next_screen() -> bool:
            deadline = time.monotonic() + after_timeout
            while time.monotonic() < deadline:
                if expected_after():
                    time.sleep(min(wait_after, 0.5))
                    return True
                time.sleep(poll_interval)
            return False

        if wait_for_next_screen():
            return

        # TikTok sometimes renders a reason row very close to the bottom
        # of the scrollable sheet. UiAutomator can find that text while the
        # first click is ignored by the sheet. Retry only reason/subreason
        # rows, only when the expected next screen did not appear. The same
        # selector is resolved again; no coordinate fallback is introduced.
        retry_count = int(
            self.config.get(
                "reason_postcondition_retry_count",
                1,
            )
        ) if selector_key in {
            "report_reason",
            "report_subreason",
        } else 0

        for retry_index in range(retry_count):
            self.logger.warning(
                "%s: layar berikutnya belum terverifikasi; "
                "mencoba ulang selector yang sama (%d/%d).",
                action,
                retry_index + 1,
                retry_count,
            )

            if expected_after():
                time.sleep(min(wait_after, 0.5))
                return

            moved = self.scroll_reason_list_once()
            if moved:
                self.logger.info(
                    "SCROLL | Menempatkan ulang item alasan sebelum retry"
                )
                time.sleep(poll_interval)

            try:
                retry_target, retry_located = self.locate_unique(
                    action=action + " (retry)",
                    selector_config=selector_config,
                    timeout=float(
                        self.config.get(
                            "reason_retry_selector_timeout_seconds",
                            4,
                        )
                    ),
                    scroll_on_miss=True,
                    max_scroll_attempts=1,
                )
            except WorkflowError:
                if expected_after():
                    time.sleep(min(wait_after, 0.5))
                    return
                break

            if expected_after():
                time.sleep(min(wait_after, 0.5))
                return

            self.logger.info(
                "SELECTOR RETRY | %s | %s | id=%s | "
                "text=%r | desc=%r | bounds=%s",
                action,
                retry_located.selector.name,
                retry_located.resource_id,
                retry_located.text,
                retry_located.description,
                retry_located.bounds,
            )
            self.logger.info("CLICK RETRY | %s", action)
            retry_target.click()

            if wait_for_next_screen():
                return

        if selector_key == "report_reason" and (
            self.exact_text_exists("report_description_title", timeout=0.2)
            or self.exact_text_exists("submit_button", timeout=0.2)
        ):
            self.save_state(
                "error_report_flow_changed_" + safe_name(action)
            )
            raise WorkflowError(
                f"{action}: report flow changed; the description/Submit form "
                "opened without the configured subreason being visible."
            )

        self.save_state(
            "error_postcondition_" + safe_name(action)
        )
        if retry_count:
            detail = (
                f"setelah {retry_count} retry selector semantik"
            )
        else:
            detail = "setelah klik; postcondition tidak muncul"
        raise WorkflowError(
            f"{action}: layar berikutnya tidak terverifikasi {detail}."
        )

    def exact_text_exists(
        self,
        selector_key: str,
        timeout: float = 0.2,
    ) -> bool:
        assert self.device is not None

        selector_config = self.config[
            "selectors"
        ][selector_key]

        values = []
        primary = normalize(
            selector_config.get("text")
        )
        if primary:
            values.append(primary)

        values.extend(
            normalize(value)
            for value in selector_config.get(
                "alternate_texts",
                [],
            )
            if normalize(value)
        )

        for value in values:
            try:
                if self.device(
                    text=value
                ).exists(timeout=timeout):
                    return True
            except Exception:
                continue

        return False

    def resource_id_exists(
        self,
        selector_key: str,
        timeout: float = 0.2,
    ) -> bool:
        assert self.device is not None

        resource_id = normalize(
            self.config["selectors"][
                selector_key
            ].get("resource_id")
        )

        if not resource_id:
            return False

        try:
            return self.device(
                resourceId=resource_id
            ).exists(timeout=timeout)
        except Exception:
            return False

    def selector_exists(
        self,
        selector_key: str,
        timeout: float = 0.3,
    ) -> bool:
        """Check every configured selector variant without clicking it."""
        assert self.device is not None
        selector_config = self.config["selectors"][selector_key]
        deadline = time.monotonic() + timeout
        specs = self.selector_specs(selector_config)
        while time.monotonic() < deadline:
            for spec in specs:
                try:
                    target = self.device(**spec.values)
                    count = int(target.count)
                    if count < 1:
                        continue
                    for index in range(min(count, 5)):
                        item = target if count == 1 else target[index]
                        info = item.info
                        if info.get("enabled") is False:
                            continue
                        if parse_bounds(
                            info.get("visibleBounds") or info.get("bounds")
                        ) is not None:
                            return True
                except Exception:
                    continue
            time.sleep(0.1)
        return False

    def classify_error(
        self, exc: Exception
    ) -> tuple[str, str, str]:
        message = str(exc)
        lowered = message.lower()
        exc_name = type(exc).__name__
        stage = self.current_stage

        if "report_history_name_missing" in lowered:
            return (
                "REPORT_HISTORY_NAME_MISSING",
                "The report-history screen opened, but none of the captured "
                "broadcaster identity candidates appeared in the visible list.",
                "Inspect error_ui.xml and confirm whether TikTok displays the "
                "username, display name, or another localized label. Update only "
                "the semantic history selectors; do not use coordinates.",
            )
        if "command timeout" in lowered:
            return (
                "ADB_COMMAND_TIMEOUT",
                "ADB did not answer before timeout, usually because the TCP "
                "device disconnected, responded slowly, or the ADB server was busy.",
                "Confirm the serial is 'device' in adb devices -l and lower the "
                "maximum parallel value for slow networks/devices.",
            )
        if "remote end closed connection" in lowered:
            return (
                "UIAUTOMATOR_CONNECTION_CLOSED",
                "The device closed the uiautomator2 RPC connection during the step.",
                "Reconnect that TCP device and rerun it. Check atx-agent/uiautomator2 "
                "health on that device if the same serial repeats this error.",
            )
        if "-32002" in message or "UiObjectNotFound" in exc_name:
            return (
                "SELECTOR_BECAME_STALE",
                "The UI changed between selector discovery and click execution.",
                "Use the saved selector attempts and UI hierarchy. The workflow "
                "already retries the same semantic selector once.",
            )
        if "package tiktok tidak ditemukan" in lowered:
            return (
                "TIKTOK_PACKAGE_NOT_FOUND",
                "TikTok is not installed under a known or uniquely identifiable "
                "package name on this device.",
                "Install/open TikTok on the device, or set tiktok_package in that "
                "action's config.json when the package name is known.",
            )

        ambiguous = "selector ambigu" in lowered
        missing = (
            "selector tidak ditemukan" in lowered
            or "tidak menemukan selector unik" in lowered
        )
        if ambiguous or missing:
            suffix = "AMBIGUOUS" if ambiguous else "MISSING"
            stage_map = {
                "HOST_PROFILE": (
                    f"HOST_PROFILE_SELECTOR_{suffix}",
                    "The broadcaster header selector matched multiple elements."
                    if ambiguous else
                    "No visible enabled broadcaster-header element matched.",
                    "Inspect host-profile candidate IDs/text in error_report.txt; "
                    "update the semantic resource ID/class only.",
                ),
                "REPORT_MENU": (
                    f"REPORT_BUTTON_SELECTOR_{suffix}",
                    "The Report control matched multiple elements."
                    if ambiguous else
                    "The profile sheet opened, but no valid Report control matched.",
                    "Inspect the profile-sheet UI and update the Report resource "
                    "ID/description/text only.",
                ),
                "REPORT_REASON": (
                    f"REPORT_REASON_SELECTOR_{suffix}",
                    "The requested report-reason row was ambiguous."
                    if ambiguous else
                    "The report-reason sheet did not contain the configured reason.",
                    "Check language and TikTok report taxonomy in error_ui.xml, then "
                    "update the exact reason text if the UI evidence confirms it.",
                ),
                "REPORT_SUBREASON": (
                    f"REPORT_SUBREASON_SELECTOR_{suffix}",
                    "The requested report-subreason row was ambiguous."
                    if ambiguous else
                    "The configured report subreason was not present on this layout.",
                    "Inspect the visible subreason labels and update only the exact "
                    "localized text when confirmed.",
                ),
                "REPORT_HISTORY_VERIFY": (
                    f"REPORT_HISTORY_SELECTOR_{suffix}",
                    "The View your reports/history selector was ambiguous."
                    if ambiguous else
                    "The View your reports/history control was not found.",
                    "Inspect the post-report UI and update the semantic text or "
                    "resource ID. This verification call remains commented in dry mode.",
                ),
            }
            if stage in stage_map:
                return stage_map[stage]
            return (
                f"SELECTOR_{suffix}",
                "More than one valid UI element matched." if ambiguous else
                "No valid visible and enabled UI element matched before timeout.",
                "Inspect selector counts and error_ui.xml; update only semantic "
                "resource ID/text/description values.",
            )

        if "report flow changed" in lowered:
            return (
                "REPORT_FLOW_CHANGED",
                "TikTok opened a different report form/taxonomy than configured.",
                "Inspect the visible reason and subreason labels and update only the "
                "confirmed text for that TikTok version.",
            )
        if "layar berikutnya tidak terverifikasi" in lowered:
            stage_map = {
                "HOST_PROFILE": (
                    "PROFILE_SHEET_NOT_OPENED",
                    "The broadcaster header was clicked, but the profile sheet/Report "
                    "control did not appear.",
                    "Check for an overlay, stale sheet, or changed Report selector in "
                    "the saved UI hierarchy.",
                ),
                "REPORT_MENU": (
                    "REPORT_REASON_SHEET_NOT_OPENED",
                    "The Report control was clicked, but 'Select a reason' did not appear.",
                    "Inspect the UI after the click for a language/layout change or an "
                    "intercepting overlay.",
                ),
                "REPORT_REASON": (
                    "REPORT_SUBREASON_SHEET_NOT_OPENED",
                    "The reason row was clicked, but the configured subreason did not appear.",
                    "Check whether TikTok changed the taxonomy or whether the list was "
                    "still animating; use the saved UI evidence.",
                ),
                "REPORT_SUBREASON": (
                    "REPORT_FORM_NOT_OPENED",
                    "The subreason row was clicked, but the report-description/Submit "
                    "screen did not appear.",
                    "Inspect the post-click UI and update the expected title/button text "
                    "only when confirmed.",
                ),
            }
            if stage in stage_map:
                return stage_map[stage]
            return (
                "POSTCONDITION_NOT_MET",
                "The click occurred, but the expected next UI was not detected.",
                "Inspect current activity, selector attempts, and relevant UI nodes.",
            )
        if "live tidak siap" in lowered:
            return (
                "LIVE_NOT_READY",
                "TikTok did not remain in a recognized LIVE activity before timeout.",
                "Confirm the LIVE is active, the account is logged in, and the deep "
                "link opens correctly on that device.",
            )
        if "gagal menghubungkan adb" in lowered or "state adb" in lowered:
            return (
                "ADB_CONNECTION_FAILED",
                "The TCP serial did not reach ADB state 'device'.",
                "Reconnect it and confirm adb devices -l reports state 'device'.",
            )
        return (
            "UNEXPECTED_ERROR",
            f"Unhandled {exc_name} occurred during stage {stage}.",
            "Use ERROR_SUMMARY.txt, error_report.txt, selector attempts, and "
            "error_ui.xml in the same run directory.",
        )

    def build_concise_error_evidence(self, error_code: str) -> str:
        current = {"package": "", "activity": ""}
        if self.device is not None:
            try:
                current = self.current_app()
            except Exception:
                pass
        counts: list[str] = []
        for item in self.last_selector_diagnostics[-12:]:
            if "count" in item:
                counts.append(
                    f"{item.get('selector', 'selector')}={item.get('count')}"
                )
        selector_counts = ",".join(counts) or "none"
        return (
            f"code={error_code}; stage={self.current_stage}; "
            f"action={self.current_action}; app={current.get('package', '')}/"
            f"{current.get('activity', '')}; selector_counts={selector_counts}; "
            f"cleanup={len(self.optional_cleanup_actions)}"
        )

    def write_error_report(
        self,
        exc: Exception,
        error_code: str,
        likely_cause: str,
        suggested_solution: str,
    ) -> Path:
        current_app = {"package": "", "activity": ""}
        if self.device is not None:
            try:
                current_app = self.current_app()
            except Exception:
                pass

        adb_state = "unavailable"
        try:
            result = self.adb("get-state", timeout=8)
            adb_state = normalize(result.stdout) or normalize(result.stderr)
        except Exception as state_exc:
            adb_state = f"unavailable: {state_exc}"

        hierarchy = ""
        if self.device is not None:
            try:
                hierarchy = self.device.dump_hierarchy(compressed=False)
                (self.run_dir / "error_ui.xml").write_text(
                    hierarchy, encoding="utf-8"
                )
            except Exception as hierarchy_exc:
                hierarchy = f"UI hierarchy unavailable: {hierarchy_exc}"

        relevant_nodes: list[str] = []
        if hierarchy.startswith("<?xml") or hierarchy.startswith("<hierarchy"):
            try:
                root = ET.fromstring(hierarchy)
                for node in root.iter("node"):
                    resource_id = normalize(node.attrib.get("resource-id"))
                    text = normalize(node.attrib.get("text"))
                    description = normalize(node.attrib.get("content-desc"))
                    class_name = normalize(node.attrib.get("class"))
                    clickable = normalize(node.attrib.get("clickable"))
                    enabled = normalize(node.attrib.get("enabled"))
                    bounds = normalize(node.attrib.get("bounds"))
                    searchable = " ".join(
                        (resource_id, text, description)
                    ).lower()
                    important = (
                        clickable == "true"
                        or any(
                            token in searchable
                            for token in (
                                "report", "lapor", "submit", "done", "verify",
                                "close", "misinformation", "false information",
                                "fraud", "harassment", "violent", "hateful",
                                "gambling", "criminal",
                            )
                        )
                    )
                    if not important:
                        continue
                    relevant_nodes.append(
                        f"{resource_id} | {class_name} | text={text!r} | "
                        f"desc={description!r} | bounds={bounds} | "
                        f"clickable={clickable} | enabled={enabled}"
                    )
                    if len(relevant_nodes) >= 120:
                        relevant_nodes.append("... relevant nodes truncated ...")
                        break
            except Exception as parse_exc:
                relevant_nodes.append(f"UI parse failed: {parse_exc}")

        related_packages = [
            package
            for package in self.installed_packages
            if any(
                marker in package.lower()
                for marker in ("tiktok", "musically", "aweme", "trill")
            )
        ]

        evidence = self.build_concise_error_evidence(error_code)
        self.last_error_evidence = evidence

        lines = [
            "TIKTOK LIVE WORKFLOW ERROR REPORT",
            "=" * 72,
            f"timestamp: {datetime.now().isoformat(timespec='milliseconds')}",
            f"build: {BUILD_ID}",
            f"workflow_file: {Path(__file__).resolve()}",
            f"config_file: {self.config_path}",
            f"adb_serial: {self.serial}",
            f"adb_state: {adb_state}",
            f"live_url: {self.live_url}",
            f"report_action_id: {normalize(self.config.get('report_action_id'))}",
            f"report_type: {normalize(self.config.get('report_type'))}",
            f"assignment_mode: {normalize(self.config.get('assignment_mode'))}",
            f"optional_cleanup_actions: {json.dumps(self.optional_cleanup_actions, ensure_ascii=False)}",
            f"stage: {self.current_stage}",
            f"action: {self.current_action}",
            f"current_app: {json.dumps(current_app, ensure_ascii=False)}",
            f"error_code: {error_code}",
            f"exception_type: {type(exc).__name__}",
            f"exception: {exc}",
            "",
            "CONCISE EVIDENCE",
            evidence,
            "",
            "LIKELY CAUSE",
            likely_cause,
            "",
            "SUGGESTED SOLUTION",
            suggested_solution,
            "",
            "RELATED TIKTOK PACKAGES",
            ", ".join(related_packages) or "none detected",
            "",
            "LAST SELECTOR ATTEMPTS",
            json.dumps(
                self.last_selector_diagnostics,
                indent=2,
                ensure_ascii=False,
                default=str,
            ),
            "",
            "RELEVANT UI NODES",
            *(relevant_nodes or ["none available"]),
            "",
            "TRACEBACK",
            "".join(traceback.format_exception(type(exc), exc, exc.__traceback__)),
        ]
        report_path = self.run_dir / "error_report.txt"
        report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

        summary_lines = [
            "ERROR SUMMARY",
            "=" * 72,
            f"timestamp: {datetime.now().isoformat(timespec='milliseconds')}",
            f"device: {self.serial}",
            f"live: @{self.live_username}",
            f"report_type: {normalize(self.config.get('report_type'))}",
            f"error_code: {error_code}",
            f"stage: {self.current_stage}",
            f"action: {self.current_action}",
            f"root_cause: {likely_cause}",
            f"evidence: {evidence}",
            f"solution: {suggested_solution}",
            f"details: {report_path.name}, error_ui.xml",
        ]
        summary_path = self.run_dir / "ERROR_SUMMARY.txt"
        summary_path.write_text(
            "\n".join(summary_lines) + "\n", encoding="utf-8"
        )
        return report_path

    def ui_contains_any_text(self, values: Iterable[str]) -> bool:
        """Return True when the current hierarchy contains any supplied text."""
        assert self.device is not None
        needles = [normalize(value).lower() for value in values if normalize(value)]
        if not needles:
            return False
        try:
            hierarchy = self.device.dump_hierarchy(compressed=True).lower()
        except Exception:
            return False
        return any(needle in hierarchy for needle in needles)

    def verification_control_workflow(self) -> bool:
        """Optionally close a verification banner when a close control exists.

        This does not solve or bypass CAPTCHA/security verification. It only
        clicks a configured close/dismiss control when exactly one valid
        control is visible. Missing or ambiguous controls are ignored.
        """
        assert self.device is not None
        if not bool(self.config.get("optional_preflight_cleanup_enabled", True)):
            return False

        selector_config = self.config["selectors"]["verification_close"]
        context_values = selector_config.get(
            "context_texts",
            ["Verify", "Verification", "Verifikasi", "Security check"],
        )
        context_present = self.ui_contains_any_text(context_values)
        diagnostics: list[dict[str, Any]] = []

        for spec in self.selector_specs(selector_config):
            try:
                target = self.device(**spec.values)
                count = int(target.count)
                diagnostics.append(
                    {"selector": spec.name, "values": spec.values, "count": count}
                )
                if count != 1:
                    continue

                # Generic Close/Tutup text is only safe when verification
                # context is also visible. Specific resource IDs may be used
                # without that text context.
                if spec.name in {"description", "text", "alternate-text"} and not context_present:
                    continue

                info = target.info
                if info.get("enabled") is False or not bool(info.get("clickable", False)):
                    continue
                if parse_bounds(info.get("visibleBounds") or info.get("bounds")) is None:
                    continue

                self.logger.info(
                    "OPTIONAL CLEANUP | verification close found | selector=%s | "
                    "id=%s | text=%r | desc=%r",
                    spec.name,
                    normalize(info.get("resourceName")),
                    normalize(info.get("text")),
                    normalize(info.get("contentDescription")),
                )
                target.click()
                wait_after = float(selector_config.get("wait_after_seconds", 0.5))
                time.sleep(wait_after)
                self.optional_cleanup_actions.append("closed verification banner")
                return True
            except Exception as exc:
                diagnostics.append(
                    {"selector": spec.name, "values": spec.values, "error": str(exc)}
                )

        ambiguous = [
            item for item in diagnostics
            if isinstance(item.get("count"), int) and int(item["count"]) > 1
        ]
        if ambiguous:
            self.logger.info(
                "OPTIONAL CLEANUP | verification close ambiguous; skipped | attempts=%s",
                json.dumps(ambiguous, ensure_ascii=False),
            )
        else:
            self.logger.info("OPTIONAL CLEANUP | verification banner not present")
        return False

    def optional_preflight_cleanup(self) -> None:
        """Close optional blockers or stale report sheets before core steps.

        Nothing is required: when no blocker is present, the workflow proceeds
        immediately. No coordinates are used.
        """
        if not bool(self.config.get("optional_preflight_cleanup_enabled", True)):
            self.logger.info("OPTIONAL CLEANUP | disabled")
            return

        try:
            self.verification_control_workflow()
        except Exception as exc:
            self.logger.warning(
                "OPTIONAL CLEANUP | verification check failed but is non-fatal: %s",
                exc,
            )

        max_back_attempts = int(self.config.get("optional_cleanup_back_attempts", 3))

        for _attempt in range(max_back_attempts):
            selectors = self.config.get("selectors", {})
            thanks_visible = (
                "thanks_title" in selectors
                and self.exact_text_exists("thanks_title", timeout=0.15)
            )
            reason_sheet_visible = (
                "select_reason_title" in selectors
                and self.exact_text_exists("select_reason_title", timeout=0.15)
            )
            description_form_visible = (
                "report_description_title" in selectors
                and self.exact_text_exists("report_description_title", timeout=0.15)
            )
            profile_sheet_visible = (
                "report_button" in selectors
                and self.selector_exists("report_button", timeout=0.15)
            )
            submit_visible = (
                description_form_visible
                and "submit_button" in selectors
                and self.selector_exists("submit_button", timeout=0.15)
            )
            done_visible = (
                thanks_visible
                and "done_button" in selectors
                and self.selector_exists("done_button", timeout=0.15)
            )

            visible_markers: list[str] = []
            if thanks_visible:
                visible_markers.append("thanks_title")
            if done_visible:
                visible_markers.append("done_button")
            if reason_sheet_visible:
                visible_markers.append("select_reason_title")
            if description_form_visible:
                visible_markers.append("report_description_title")
            if submit_visible:
                visible_markers.append("submit_button")
            if profile_sheet_visible:
                visible_markers.append("report_button")

            if not visible_markers:
                break

            self.logger.info(
                "OPTIONAL CLEANUP | stale modal/sheet detected=%s | action=BACK",
                ",".join(visible_markers),
            )
            try:
                self.device.press("back")
            except Exception as exc:
                self.logger.warning(
                    "OPTIONAL CLEANUP | BACK failed but is non-fatal: %s", exc
                )
                break
            self.optional_cleanup_actions.append(
                "closed stale UI: " + ",".join(visible_markers)
            )
            time.sleep(0.6)

        if not self.live_context_ok():
            self.logger.info(
                "OPTIONAL CLEANUP | LIVE context changed; reopening the same LIVE URL"
            )
            self.open_live()
            self.optional_cleanup_actions.append("reopened LIVE after cleanup")

        if self.optional_cleanup_actions:
            self.logger.info(
                "OPTIONAL CLEANUP | completed | actions=%s",
                json.dumps(self.optional_cleanup_actions, ensure_ascii=False),
            )
        else:
            self.logger.info("OPTIONAL CLEANUP | no blocking UI detected")


    def verify_report_history_contains_broadcaster(self) -> None:
        """Prepared post-report verification; invocation remains commented.

        When manually enabled after Submit and Done, this opens the semantic
        "View your reports" control and verifies that either the LIVE URL
        username or the captured broadcaster display name is present. A missing
        name raises WorkflowError, so the device/URL job is counted as failed.
        No coordinates are used.
        """
        assert self.device is not None
        self.report_history_check = "running"
        self.report_history_name_match = False
        self.report_history_matched_value = ""

        self.click_action(
            action="Buka View your reports",
            selector_key="view_your_reports_button",
            expected_after=lambda: (
                self.selector_exists("report_history_title", timeout=0.5)
                or self.ui_contains_any_text(
                    self.config["selectors"]["report_history_title"].get(
                        "alternate_texts", []
                    )
                    + [
                        self.config["selectors"]["report_history_title"].get(
                            "text", ""
                        )
                    ]
                )
            ),
        )

        candidates = list(self.broadcaster_identity_candidates)
        for raw in (self.live_username, "@" + self.live_username):
            normalized = normalize_identity(raw)
            if len(normalized) >= 3 and normalized not in candidates:
                candidates.append(normalized)

        max_scrolls = int(self.config.get("report_history_scroll_attempts", 5))
        for attempt in range(max_scrolls + 1):
            hierarchy = self.device.dump_hierarchy(compressed=False)
            searchable_parts: list[str] = []
            try:
                root = ET.fromstring(hierarchy)
                for node in root.iter("node"):
                    searchable_parts.extend(
                        [
                            normalize(node.attrib.get("text")),
                            normalize(node.attrib.get("content-desc")),
                        ]
                    )
            except ET.ParseError:
                searchable_parts.append(hierarchy)

            searchable = normalize_identity(" ".join(searchable_parts))
            for candidate in candidates:
                if candidate and candidate in searchable:
                    self.report_history_check = "verified"
                    self.report_history_name_match = True
                    self.report_history_matched_value = candidate
                    self.logger.info(
                        "REPORT HISTORY VERIFIED | broadcaster=%r | attempt=%d",
                        candidate,
                        attempt + 1,
                    )
                    return

            if attempt >= max_scrolls:
                break
            try:
                scrollable = self.device(scrollable=True)
                if int(scrollable.count) < 1:
                    break
                moved = bool(scrollable[0].scroll.forward(steps=30))
                self.logger.info(
                    "REPORT HISTORY SCROLL | attempt=%d | moved=%s",
                    attempt + 1,
                    moved,
                )
                if not moved:
                    break
                time.sleep(0.5)
            except Exception as exc:
                self.logger.warning(
                    "REPORT HISTORY SCROLL failed: %s", exc
                )
                break

        self.report_history_check = "failed_name_missing"
        self.save_state("error_report_history_name_missing")
        raise WorkflowError(
            "REPORT_HISTORY_NAME_MISSING: View your reports terbuka, "
            "tetapi username/display name livestreamer tidak ditemukan."
        )

    def live_context_ok(self) -> bool:
        assert self.package

        current = self.current_app()
        if current["package"] != self.package:
            return False

        return any(
            normalize(fragment).lower()
            in current["activity"].lower()
            for fragment in self.config.get(
                "live_activity_contains",
                ["LivePlayActivity", ".live."],
            )
        )

    def close_tiktok(self) -> None:
        if not self.package:
            return

        self.logger.info("Menutup TikTok...")

        try:
            self.adb(
                "shell",
                "am",
                "force-stop",
                self.package,
                timeout=20,
            )
        except Exception as exc:
            self.logger.warning(
                "Gagal menutup TikTok: %s",
                exc,
            )

    def run_workflow(self) -> None:
        self.set_stage("OPEN_LIVE", "Open TikTok LIVE deep link")
        self.open_live()

        self.set_stage(
            "OPTIONAL_PREFLIGHT",
            "Close optional verification/stale UI when present",
        )
        self.optional_preflight_cleanup()

        self.set_stage("HOST_PROFILE", "Open broadcaster profile sheet")
        self.click_action(
            action="Buka profil host LIVE",
            selector_key="host_profile",
            expected_before=self.live_context_ok,
            expected_after=lambda: (
                self.selector_exists(
                    "report_button",
                    timeout=0.5,
                )
            ),
        )
        self.save_state("02_profile_sheet")

        self.set_stage("REPORT_MENU", "Open Report menu")
        self.click_action(
            action="Buka menu Report",
            selector_key="report_button",
            expected_after=lambda: (
                self.exact_text_exists(
                    "select_reason_title",
                    timeout=0.3,
                )
            ),
        )
        self.save_state("03_select_reason")

        self.set_stage("REPORT_REASON", "Choose report reason")
        self.click_action(
            action=(
                "Pilih alasan laporan: "
                + normalize(
                    self.config["selectors"][
                        "report_reason"
                    ].get("text")
                )
            ),
            selector_key="report_reason",
            expected_before=lambda: (
                self.exact_text_exists(
                    "select_reason_title",
                    timeout=0.3,
                )
            ),
            expected_after=lambda: (
                self.exact_text_exists(
                    "report_description_title",
                    timeout=0.3,
                )
                or self.exact_text_exists(
                    "submit_button",
                    timeout=0.3,
                )
            ),
        )
        self.save_state("04_report_description")

        # OPTIONAL CONFIRMATION TEMPLATE (INTENTIONALLY COMMENTED).
        # Submit and Done are already commented below, so no additional
        # confirmation or safety mechanism runs in this dry workflow.
        # require_confirmation = bool(
        #     self.config.get("require_confirmation_before_submit", False)
        # )
        # if require_confirmation:
        #     answer = input(
        #         "Ketik SUBMIT untuk mengirim laporan, "
        #         "atau tekan Enter untuk batal: "
        #     ).strip()
        #     if answer != "SUBMIT":
        #         raise WorkflowError(
        #             "Pengiriman laporan dibatalkan oleh pengguna."
        #         )

        # DRY-RUN: Submit and Done execution remains below as comments.
        # No report is sent automatically.
#         self.click_action(
#             action="Kirim laporan",
#             selector_key="submit_button",
#             expected_after=lambda: (
#                 self.exact_text_exists(
#                     "thanks_title",
#                     timeout=0.3,
#                 )
#                 or self.exact_text_exists(
#                     "done_button",
#                     timeout=0.3,
#                 )
#             ),
#         )
#         self.save_state("05_report_success")

#         self.click_action(
#             action="Selesaikan dialog laporan",
#             selector_key="done_button",
#             expected_before=lambda: (
#                 self.exact_text_exists(
#                     "thanks_title",
#                     timeout=0.3,
#                 )
#                 or self.exact_text_exists(
#                     "done_button",
#                     timeout=0.3,
#                 )
#             ),
#             expected_after=lambda: (
#                 self.live_context_ok()
#                 or self.resource_id_exists(
#                     "host_profile",
#                     timeout=0.3,
#                 )
#             ),
#         )
#         self.save_state("06_done")

        # POST-REPORT HISTORY VERIFICATION TEMPLATE (INTENTIONALLY COMMENTED).
        # It is placed after the already-commented Submit and Done sequence.
        # When manually enabled in a non-dry test, a missing broadcaster name
        # raises REPORT_HISTORY_NAME_MISSING and counts that job as failed.
#         self.set_stage(
#             "REPORT_HISTORY_VERIFY",
#             "Verify broadcaster name in View your reports",
#         )
#         self.verify_report_history_contains_broadcaster()
#         self.save_state("08_report_history_verified")

        self.set_stage("DRY_RUN_READY", "Reached screen before Submit")
        self.logger.info(
            "DRY RUN selesai di layar sebelum Submit. "
            "Pemanggilan Submit dan Done tetap dikomentari."
        )

    def execute(self) -> int:
        result = {
            "build": BUILD_ID,
            "started_at": datetime.now().isoformat(
                timespec="milliseconds"
            ),
            "adb_serial": self.serial,
            "live_url": self.live_url,
            "username": self.live_username,
            "report_action_id": normalize(self.config.get("report_action_id")),
            "report_type": normalize(self.config.get("report_type")),
            "assignment_mode": normalize(self.config.get("assignment_mode")),
            "status": "failed",
            "fixed_coordinates_used": False,
            "coordinate_ratios_used": False,
        }

        exit_code = 1

        try:
            self.logger.info(
                "Build: %s | Mode: DRY RUN (Submit/Done commented)",
                BUILD_ID,
            )
            self.logger.info(
                "Workflow file: %s",
                Path(__file__).resolve(),
            )
            self.logger.info(
                "Workflow SHA256: %s", self.source_sha256
            )
            self.logger.info(
                "Post-report View your reports verification: COMMENTED"
            )
            self.set_stage("CONNECT_ADB", "Connect ADB TCP and uiautomator2")
            self.connect()
            self.set_stage("DETECT_PACKAGE", "Detect TikTok package")
            self.detect_package()
            self.run_workflow()

            result["status"] = "success"
            result["stage"] = self.current_stage
            result["action"] = self.current_action
            exit_code = 0
            self.logger.info(
                "Workflow selesai dengan sukses."
            )

        except LiveUnavailableError as exc:
            result["status"] = "skipped"
            result["stage"] = self.current_stage
            result["action"] = self.current_action
            result["reason"] = str(exc)
            exit_code = 0
            self.logger.warning("SKIP | %s", exc)

        except KeyboardInterrupt:
            result["status"] = "cancelled"
            result["error"] = "Dibatalkan pengguna."
            exit_code = 130
            self.logger.error(
                "Workflow dibatalkan pengguna."
            )

        except Exception as exc:
            error_code, likely_cause, suggested_solution = (
                self.classify_error(exc)
            )
            result["status"] = "failed"
            result["error"] = str(exc)
            result["error_code"] = error_code
            result["stage"] = self.current_stage
            result["action"] = self.current_action
            result["likely_cause"] = likely_cause
            result["suggested_solution"] = suggested_solution
            evidence = self.build_concise_error_evidence(error_code)
            result["root_cause_evidence"] = evidence
            exit_code = 1
            report_path = self.write_error_report(
                exc,
                error_code,
                likely_cause,
                suggested_solution,
            )
            result["error_report"] = str(report_path)
            summary_path = self.run_dir / "ERROR_SUMMARY.txt"
            result["error_summary"] = str(summary_path)
            self.logger.error(
                "ERROR_CODE | %s | stage=%s | action=%s",
                error_code,
                self.current_stage,
                self.current_action,
            )
            self.logger.error("CAUSE | %s", likely_cause)
            self.logger.error("SOLUTION | %s", suggested_solution)
            self.logger.error("ERROR_REPORT | %s", report_path)
            self.logger.exception("Workflow gagal: %s", exc)

        finally:
            result["optional_cleanup_actions"] = list(
                self.optional_cleanup_actions
            )
            result["broadcaster_identity_candidates"] = list(
                self.broadcaster_identity_candidates
            )
            result["report_history_check"] = self.report_history_check
            result["report_history_name_match"] = (
                self.report_history_name_match
            )
            result["report_history_matched_value"] = (
                self.report_history_matched_value
            )
            result["finished_at"] = (
                datetime.now().isoformat(
                    timespec="milliseconds"
                )
            )

            (self.run_dir / "result.json").write_text(
                json.dumps(
                    result,
                    indent=2,
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )

            self.close_tiktok()

        return exit_code


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "TikTok LIVE selector-only Android workflow."
        )
    )
    parser.add_argument(
        "--config",
        default="config.json",
    )
    args = parser.parse_args()

    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = (
            Path(__file__).resolve().parent
            / config_path
        )

    return TikTokSelectorWorkflow(
        config_path
    ).execute()


if __name__ == "__main__":
    raise SystemExit(main())
