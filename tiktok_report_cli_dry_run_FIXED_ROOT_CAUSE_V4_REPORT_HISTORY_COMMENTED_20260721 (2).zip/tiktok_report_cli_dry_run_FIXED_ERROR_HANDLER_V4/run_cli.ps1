$ErrorActionPreference = "Stop"
$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = $Utf8NoBom
$OutputEncoding = $Utf8NoBom
Set-Location $PSScriptRoot

if (-not (Get-Command adb -ErrorAction SilentlyContinue)) {
    throw "adb.exe not found in PATH."
}
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    throw "Python not found in PATH."
}

python -c "import uiautomator2"
if ($LASTEXITCODE -ne 0) {
    python -m pip install -U uiautomator2
    if ($LASTEXITCODE -ne 0) {
        throw "uiautomator2 installation failed."
    }
}

python "$PSScriptRoot\cli_runner.py"
exit $LASTEXITCODE
