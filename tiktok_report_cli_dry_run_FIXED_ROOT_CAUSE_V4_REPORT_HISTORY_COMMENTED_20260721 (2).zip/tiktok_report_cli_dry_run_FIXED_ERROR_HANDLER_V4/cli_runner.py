#!/usr/bin/env python3
"""Multi-device dry-run CLI for TikTok LIVE selector workflows.

The workflow stops before Submit. Submit and Done remain commented in every
workflow script. All currently connected ADB TCP devices are discovered
automatically; adb_addresses.txt is not used.
"""

from __future__ import annotations

import concurrent.futures
import csv
import json
import os
import random
import re
import subprocess
import sys
import threading
from datetime import datetime
from pathlib import Path


def configure_utf8_streams() -> None:
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is None or not hasattr(stream, "reconfigure"):
            continue
        try:
            stream.reconfigure(encoding="utf-8", errors="backslashreplace")
        except (OSError, ValueError):
            pass


configure_utf8_streams()

BASE_DIR = Path(__file__).resolve().parent
URLS_FILE = BASE_DIR / "live_urls.txt"
RUNTIME_DIR = BASE_DIR / ".runtime_configs"
LOGS_DIR = BASE_DIR / "cli_logs"
DEFAULT_MAX_PARALLEL_DEVICES = 20
BUILD_ID = "2026.07.21-DRY-ROOT-CAUSE-V4"

ACTIONS = {
    "1": {"label": "Report Fraud", "project_dir": BASE_DIR / "fraud"},
    "2": {
        "label": "Report Hateful behavior - Attacks and slurs on the basis of protected attributes",
        "project_dir": BASE_DIR / "hateful-attacks",
    },
    "3": {
        "label": "Illegal activities and regulated goods - Gambling",
        "project_dir": BASE_DIR / "illegal-gambling",
    },
    "4": {
        "label": "Illegal activities and regulated goods - Promotion of criminal activities",
        "project_dir": BASE_DIR / "illegal-promotion-criminal-activities",
    },
    "5": {
        "label": "False information - Other misinformation",
        "project_dir": BASE_DIR / "false-other-misinformation",
    },
    "6": {
        "label": "Harassment or bullying - Others have been bullied or harassed",
        "project_dir": BASE_DIR / "harassment-bullying-others",
    },
    "7": {
        "label": "Violent and graphic content",
        "project_dir": BASE_DIR / "violent-graphic-content",
    },
    "8": {
        "label": "Violent extremism - Violent threat or incitement to violence",
        "project_dir": BASE_DIR / "violent-extremism-threat-incitement",
    },
}

PRINT_LOCK = threading.Lock()
CLI_LOG_FILE: Path | None = None


def safe_print(message: str = "") -> None:
    with PRINT_LOCK:
        print(message, flush=True)
        if CLI_LOG_FILE is not None:
            with CLI_LOG_FILE.open("a", encoding="utf-8") as handle:
                handle.write(message + "\n")


def read_entries(path: Path) -> list[str]:
    if not path.exists():
        raise SystemExit(f"Required file not found: {path}")
    entries: list[str] = []
    seen: set[str] = set()
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        value = raw.strip()
        if not value or value.startswith("#"):
            continue
        if value not in seen:
            entries.append(value)
            seen.add(value)
    if not entries:
        raise SystemExit(f"No usable entries found in: {path}")
    return entries


def validate_live_url(url: str) -> str:
    pattern = re.compile(
        r"^https?://(?:www\.)?tiktok\.com/@[A-Za-z0-9._]+/live/?$",
        re.IGNORECASE,
    )
    if not pattern.fullmatch(url):
        raise SystemExit(
            "Invalid LIVE URL in live_urls.txt:\n"
            f"  {url}\n"
            "Expected: https://www.tiktok.com/@username/live"
        )
    return url


def username_from_url(url: str) -> str:
    match = re.search(r"/@([A-Za-z0-9._]+)/live/?$", url)
    return match.group(1) if match else "unknown"


def filesystem_safe(value: str) -> str:
    result = re.sub(r"[^A-Za-z0-9._-]+", "_", value)
    return result[:100] or "unknown"


def is_tcp_adb_serial(serial: str) -> bool:
    value = serial.strip()
    if not value or value.startswith("emulator-"):
        return False
    if "._adb-tls-connect._tcp" in value:
        return True
    if ":" not in value:
        return False
    host, port_text = value.rsplit(":", 1)
    return bool(host and port_text.isdigit() and 1 <= int(port_text) <= 65535)


def discover_connected_tcp_devices() -> list[str]:
    try:
        result = subprocess.run(
            ["adb", "devices", "-l"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=20,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise SystemExit(f"Unable to run 'adb devices -l': {exc}") from exc
    if result.returncode != 0:
        detail = (result.stderr or result.stdout).strip()
        raise SystemExit(f"Unable to list ADB devices.\n{detail}")

    serials: list[str] = []
    skipped: list[str] = []
    seen: set[str] = set()
    for raw_line in result.stdout.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("List of devices attached") or line.startswith("*"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        serial, state = parts[0], parts[1]
        if state != "device":
            skipped.append(f"{serial} ({state})")
            continue
        if not is_tcp_adb_serial(serial):
            skipped.append(f"{serial} (non-TCP)")
            continue
        if serial not in seen:
            serials.append(serial)
            seen.add(serial)

    if not serials:
        details = "\n".join(f"  - {item}" for item in skipped) or "  (none)"
        raise SystemExit(
            "No connected and authorized ADB TCP devices were found.\n"
            "Run 'adb devices -l'; each device must show state 'device'.\n"
            f"Detected but not usable:\n{details}"
        )

    safe_print("Auto-detected ADB TCP devices:")
    for serial in serials:
        safe_print(f"  - {serial}")
    if skipped:
        safe_print("Ignored ADB entries:")
        for item in skipped:
            safe_print(f"  - {item}")
    safe_print()
    return serials


def choose_max_parallel(total_devices: int) -> int:
    env_value = os.environ.get("TIKTOK_MAX_PARALLEL_DEVICES", "").strip()
    try:
        env_default = int(env_value) if env_value else DEFAULT_MAX_PARALLEL_DEVICES
    except ValueError:
        env_default = DEFAULT_MAX_PARALLEL_DEVICES
    default_value = min(total_devices, max(1, env_default))

    while True:
        raw = input(
            f"Maximum parallel devices [1-{total_devices}, default {default_value}]: "
        ).strip()
        if not raw:
            return default_value
        try:
            value = int(raw)
        except ValueError:
            safe_print("Invalid value. Enter a whole number.")
            continue
        if 1 <= value <= total_devices:
            return value
        safe_print(f"Enter a number from 1 to {total_devices}.")


def choose_action_mode() -> tuple[str, str | None]:
    safe_print("Report Action:")
    for choice, action in ACTIONS.items():
        safe_print(f"{choice}. {action['label']}")
    safe_print("9. Random report type per ADB address")

    while True:
        choice = input("Choose action [1-9]: ").strip()
        if choice in ACTIONS:
            return "fixed", choice
        if choice == "9":
            return "random_per_device", None
        safe_print("Invalid choice. Enter a number from 1 to 9.")


def build_assignments(
    serials: list[str], mode: str, fixed_choice: str | None
) -> dict[str, str]:
    if mode == "fixed":
        assert fixed_choice is not None
        return {serial: fixed_choice for serial in serials}
    generator = random.SystemRandom()
    choices = sorted(ACTIONS)
    return {serial: generator.choice(choices) for serial in serials}


def write_assignment_csv(
    batch_dir: Path, assignments: dict[str, str], mode: str
) -> Path:
    path = batch_dir / "DEVICE_REPORT_ASSIGNMENTS.csv"
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["adb_serial", "report_action_id", "report_type", "assignment_mode"],
        )
        writer.writeheader()
        for serial in sorted(assignments):
            choice = assignments[serial]
            writer.writerow(
                {
                    "adb_serial": serial,
                    "report_action_id": choice,
                    "report_type": ACTIONS[choice]["label"],
                    "assignment_mode": mode,
                }
            )
    return path


def build_runtime_config(
    project_dir: Path,
    serial: str,
    live_url: str,
    action_choice: str,
    action_label: str,
    assignment_mode: str,
    batch_id: str,
) -> Path:
    source_config = project_dir / "config.json"
    config = json.loads(source_config.read_text(encoding="utf-8"))
    username = username_from_url(live_url)
    serial_name = filesystem_safe(serial)
    config["adb_serial"] = serial
    config["live_url"] = live_url
    config["report_action_id"] = action_choice
    config["report_type"] = action_label
    config["assignment_mode"] = assignment_mode
    config["optional_preflight_cleanup_enabled"] = True
    config["require_confirmation_before_submit"] = False
    config["log_root"] = str(
        (
            LOGS_DIR
            / batch_id
            / f"action_{action_choice}"
            / filesystem_safe(username)
            / serial_name
        ).resolve()
    )
    config_dir = (
        RUNTIME_DIR
        / batch_id
        / f"action_{action_choice}"
        / filesystem_safe(username)
    )
    config_dir.mkdir(parents=True, exist_ok=True)
    config_path = config_dir / f"{serial_name}.json"
    config_path.write_text(
        json.dumps(config, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return config_path


def run_one_device(
    serial: str,
    live_url: str,
    action_choice: str,
    assignment_mode: str,
    batch_id: str,
) -> tuple[str, int]:
    action = ACTIONS[action_choice]
    project_dir = Path(action["project_dir"])
    action_label = str(action["label"])
    username = username_from_url(live_url)
    prefix = f"[{serial} | A{action_choice} | @{username}]"
    config_path = build_runtime_config(
        project_dir=project_dir,
        serial=serial,
        live_url=live_url,
        action_choice=action_choice,
        action_label=action_label,
        assignment_mode=assignment_mode,
        batch_id=batch_id,
    )
    script = project_dir / "tiktok_live_selector_workflow.py"
    safe_print(f"{prefix} START | {action_label}")
    process = subprocess.Popen(
        [sys.executable, str(script), "--config", str(config_path)],
        cwd=str(project_dir),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="backslashreplace",
        bufsize=1,
    )
    assert process.stdout is not None
    for line in process.stdout:
        safe_print(f"{prefix} {line.rstrip()}")
    return_code = process.wait()
    status = "OK" if return_code == 0 else f"FAILED ({return_code})"
    safe_print(f"{prefix} {status}")
    return serial, return_code


def parse_duration(started: str, finished: str) -> str:
    try:
        seconds = (datetime.fromisoformat(finished) - datetime.fromisoformat(started)).total_seconds()
        return f"{seconds:.2f}"
    except (TypeError, ValueError):
        return ""


def action_choice_from_result_path(path: Path) -> str:
    for part in path.parts:
        match = re.fullmatch(r"action_([1-8])", part)
        if match:
            return match.group(1)
    return ""


def collect_results(batch_dir: Path) -> list[dict[str, object]]:
    results: list[dict[str, object]] = []
    for result_path in sorted(batch_dir.rglob("result.json")):
        try:
            item = json.loads(result_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            item = {
                "status": "log_error",
                "error_code": "RESULT_JSON_INVALID",
                "error": str(exc),
            }
        item["result_path"] = str(result_path)
        metadata_path = result_path.with_name("device_metadata.json")
        metadata: dict[str, object] = {}
        if metadata_path.exists():
            try:
                metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                metadata = {}
        item["device_metadata"] = metadata
        if not item.get("report_action_id"):
            item["report_action_id"] = action_choice_from_result_path(result_path)
        choice = str(item.get("report_action_id") or "")
        if not item.get("report_type") and choice in ACTIONS:
            item["report_type"] = ACTIONS[choice]["label"]
        results.append(item)
    return results


def write_workflow_csv(batch_dir: Path, results: list[dict[str, object]]) -> Path:
    path = batch_dir / "WORKFLOW_REPORT.csv"
    fields = [
        "started_at", "finished_at", "duration_seconds", "status",
        "report_action_id", "report_type", "assignment_mode", "adb_serial",
        "manufacturer", "model", "android_version", "sdk", "resolution",
        "live_username", "live_url", "stage", "action", "error_code",
        "cause", "root_cause_evidence", "error_detail", "suggested_solution",
        "optional_cleanup", "source_sha256", "broadcaster_identity",
        "report_history_check", "report_history_name_match",
        "report_history_matched_value", "error_summary_path",
        "error_report_path",
    ]
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for item in results:
            metadata = item.get("device_metadata") or {}
            if not isinstance(metadata, dict):
                metadata = {}
            width = metadata.get("window_width", "")
            height = metadata.get("window_height", "")
            resolution = f"{width}x{height}" if width and height else ""
            status = str(item.get("status", "unknown"))
            cause = str(item.get("likely_cause") or item.get("reason") or "")
            cleanup = item.get("optional_cleanup_actions") or []
            if isinstance(cleanup, list):
                cleanup_text = "; ".join(str(value) for value in cleanup)
            else:
                cleanup_text = str(cleanup)
            writer.writerow(
                {
                    "started_at": item.get("started_at", ""),
                    "finished_at": item.get("finished_at", ""),
                    "duration_seconds": parse_duration(
                        str(item.get("started_at", "")), str(item.get("finished_at", ""))
                    ),
                    "status": status,
                    "report_action_id": item.get("report_action_id", ""),
                    "report_type": item.get("report_type", ""),
                    "assignment_mode": item.get("assignment_mode", ""),
                    "adb_serial": item.get("adb_serial", ""),
                    "manufacturer": metadata.get("manufacturer", ""),
                    "model": metadata.get("model", ""),
                    "android_version": metadata.get("android_version", ""),
                    "sdk": metadata.get("sdk", ""),
                    "resolution": resolution,
                    "live_username": item.get("username", ""),
                    "live_url": item.get("live_url", ""),
                    "stage": item.get("stage", ""),
                    "action": item.get("action", ""),
                    "error_code": item.get("error_code", ""),
                    "cause": cause,
                    "root_cause_evidence": item.get("root_cause_evidence", ""),
                    "error_detail": item.get("error", ""),
                    "suggested_solution": item.get("suggested_solution", ""),
                    "optional_cleanup": cleanup_text,
                    "source_sha256": item.get("source_sha256", ""),
                    "broadcaster_identity": "; ".join(
                        str(value) for value in
                        (item.get("broadcaster_identity_candidates") or [])
                    ),
                    "report_history_check": item.get(
                        "report_history_check", "not_run_dry"
                    ),
                    "report_history_name_match": item.get(
                        "report_history_name_match", False
                    ),
                    "report_history_matched_value": item.get(
                        "report_history_matched_value", ""
                    ),
                    "error_summary_path": item.get("error_summary", ""),
                    "error_report_path": item.get("error_report", ""),
                }
            )
    return path


def write_batch_summary(batch_dir: Path) -> tuple[Path, Path, Path]:
    results = collect_results(batch_dir)
    status_counts: dict[str, int] = {}
    error_counts: dict[str, int] = {}
    for item in results:
        status = str(item.get("status", "unknown"))
        status_counts[status] = status_counts.get(status, 0) + 1
        if status == "failed":
            code = str(item.get("error_code") or "UNCLASSIFIED_ERROR")
            error_counts[code] = error_counts.get(code, 0) + 1

    payload = {
        "build": BUILD_ID,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "total_jobs": len(results),
        "status_counts": status_counts,
        "error_counts": error_counts,
        "results": results,
    }
    json_path = batch_dir / "RUN_SUMMARY.json"
    json_path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    lines = [
        f"Build: {BUILD_ID}",
        f"Generated: {payload['generated_at']}",
        f"Total jobs: {len(results)}",
        "Dry mode: Submit, Done, and View-your-reports calls are commented",
        "Report-history CSV value in dry mode: not_run_dry",
        "",
        "STATUS",
    ]
    for key in sorted(status_counts):
        lines.append(f"- {key}: {status_counts[key]}")
    lines.extend(["", "FAILURE TYPES"])
    if error_counts:
        for key, count in sorted(error_counts.items(), key=lambda item: (-item[1], item[0])):
            lines.append(f"- {key}: {count}")
    else:
        lines.append("- none")
    text_path = batch_dir / "RUN_SUMMARY.txt"
    text_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    csv_path = write_workflow_csv(batch_dir, results)
    return text_path, json_path, csv_path


def main() -> int:
    global CLI_LOG_FILE
    batch_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    batch_dir = LOGS_DIR / batch_id
    batch_dir.mkdir(parents=True, exist_ok=True)
    CLI_LOG_FILE = batch_dir / "CLI_OUTPUT.log"

    urls = [validate_live_url(item) for item in read_entries(URLS_FILE)]
    serials = discover_connected_tcp_devices()

    # Requested order: choose maximum parallel first, then report type.
    max_parallel = choose_max_parallel(len(serials))
    assignment_mode, fixed_choice = choose_action_mode()
    assignments = build_assignments(serials, assignment_mode, fixed_choice)
    assignment_csv = write_assignment_csv(batch_dir, assignments, assignment_mode)

    safe_print()
    safe_print(f"Build: {BUILD_ID}")
    safe_print(f"LIVE URLs: {len(urls)}")
    safe_print(f"ADB devices: {len(serials)} (all will be processed)")
    safe_print(f"Maximum parallel workers: {max_parallel}")
    safe_print(f"Report assignment mode: {assignment_mode}")
    if assignment_mode == "fixed":
        assert fixed_choice is not None
        safe_print(f"Selected: {ACTIONS[fixed_choice]['label']}")
    else:
        safe_print("Random report assignment per ADB address:")
        for serial in serials:
            choice = assignments[serial]
            safe_print(f"  - {serial}: A{choice} | {ACTIONS[choice]['label']}")
    safe_print(f"Assignments CSV: {assignment_csv}")
    safe_print("Mode: DRY RUN - Submit and Done are commented out")
    safe_print("View your reports verification: code prepared, call commented")
    safe_print()

    total_failures = 0
    try:
        for url_index, live_url in enumerate(urls, start=1):
            username = username_from_url(live_url)
            safe_print("=" * 72)
            safe_print(
                f"URL {url_index}/{len(urls)}: @{username}\n"
                f"Processing {len(serials)} device(s), up to {max_parallel} concurrently"
            )
            safe_print("=" * 72)

            with concurrent.futures.ThreadPoolExecutor(max_workers=max_parallel) as executor:
                futures = [
                    executor.submit(
                        run_one_device,
                        serial,
                        live_url,
                        assignments[serial],
                        assignment_mode,
                        batch_id,
                    )
                    for serial in serials
                ]
                for future in concurrent.futures.as_completed(futures):
                    try:
                        _serial, return_code = future.result()
                        if return_code != 0:
                            total_failures += 1
                    except Exception as exc:
                        total_failures += 1
                        safe_print(f"[CLI] Worker error: {exc}")

            # Refresh CSV after every URL so partial results remain available.
            _summary_txt, _summary_json, workflow_csv = write_batch_summary(batch_dir)
            safe_print(f"Completed @{username}. Current CSV: {workflow_csv}")
            safe_print()
    finally:
        summary_txt, summary_json, workflow_csv = write_batch_summary(batch_dir)

    safe_print("=" * 72)
    safe_print("CLI run complete.")
    safe_print(f"Failed device/URL jobs: {total_failures}")
    safe_print(f"Logs: {batch_dir}")
    safe_print(f"Simple CSV report: {workflow_csv}")
    safe_print(f"Summary: {summary_txt}")
    safe_print(f"Summary JSON: {summary_json}")
    safe_print("=" * 72)
    return 0 if total_failures == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
