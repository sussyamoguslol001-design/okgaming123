TikTok LIVE Multi-Device CLI - DRY ROOT CAUSE V4
==================================================

Run:
  run_cli.bat

CLI order:
  1. Detect all connected ADB TCP devices.
  2. Ask for maximum parallel devices.
  3. Ask for report action 1-8, or 9 for random action per ADB address.
  4. Process every LIVE URL from live_urls.txt.

Dry workflow:
  - Stops on the report-description screen before Submit.
  - Submit and Done calls are commented.
  - View-your-reports verification code is present but its call is commented.
  - No additional confirmation or safety mechanism is active.

Optional preflight cleanup:
  - Checks for a verification close control or stale TikTok sheet.
  - Closes only one unambiguous enabled control when verification context exists.
  - When absent or ambiguous, it logs the result and performs no close action.

Logs:
  cli_logs\YYYYMMDD_HHMMSS\WORKFLOW_REPORT.csv
  cli_logs\YYYYMMDD_HHMMSS\RUN_SUMMARY.txt
  cli_logs\YYYYMMDD_HHMMSS\RUN_SUMMARY.json
  cli_logs\YYYYMMDD_HHMMSS\CLI_OUTPUT.log

Failed jobs additionally create:
  ERROR_SUMMARY.txt       concise cause/evidence/solution
  error_report.txt        detailed selector and traceback evidence
  error_ui.xml            complete current UI hierarchy
  error_*_ui.txt          readable visible-node dump when applicable

Report-history columns in dry mode:
  report_history_check = not_run_dry
  report_history_name_match = false

The history verification cannot produce a real pass in dry mode because no
report is submitted. Its code and failure behavior are prepared and validated,
but its invocation remains commented as requested.
