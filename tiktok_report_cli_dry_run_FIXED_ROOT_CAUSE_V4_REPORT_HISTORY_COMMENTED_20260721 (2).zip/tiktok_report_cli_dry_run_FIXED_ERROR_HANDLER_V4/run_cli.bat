@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
cd /d "%~dp0"

echo ============================================================
echo TikTok LIVE Multi-Device CLI - DRY RUN
echo Build: 2026.07.21-DRY-ROOT-CAUSE-V4
echo Submit and Done remain commented in every workflow.
echo ADB TCP devices are detected automatically.
echo Maximum parallel devices is selected inside the CLI.
echo ============================================================
echo.

where adb >nul 2>nul
if errorlevel 1 (
    echo ERROR: adb.exe not found in PATH.
    pause
    exit /b 1
)

where python >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python not found in PATH.
    pause
    exit /b 1
)

python -c "import uiautomator2" >nul 2>nul
if errorlevel 1 (
    echo Installing uiautomator2...
    python -m pip install -U uiautomator2
    if errorlevel 1 (
        echo ERROR: uiautomator2 installation failed.
        pause
        exit /b 1
    )
)

python "%~dp0cli_runner.py"
set CODE=%ERRORLEVEL%

echo.
echo Exit code: %CODE%
pause
exit /b %CODE%
